"""Ensambla el informe (secciones 1 a 11) en Markdown, lo convierte con pandoc y lo ajusta."""
import re, subprocess, sys, pathlib
from docx import Document
from docx.enum.text import WD_COLOR_INDEX, WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, Cm, RGBColor

RAIZ = pathlib.Path(__file__).resolve().parent.parent
D = RAIZ / "docs"
leer = lambda p: (RAIZ / p).read_text(encoding="utf-8")
SALTO = '\n```{=openxml}\n<w:p><w:r><w:br w:type="page"/></w:r></w:p>\n```\n\n'


def spec(nombre, numero):
    t = leer(f"specs/{nombre}").split("\n", 1)
    titulo = re.sub(r"^# ", "", t[0])
    return f"## {numero} {titulo}\n\n{t[1]}\n"


def portada():
    integrantes = ["Kemmell Cabana", "Arnold Cantillo", "Jaider Lozano", "Johan Viviescas", "Sebastian Murcia"]
    filas = "\n".join(f"| {n} | [COMPLETAR código] |" for n in integrantes)
    return f"""
::: {{custom-style="PortadaGrande"}}
UNIVERSIDAD SIMÓN BOLÍVAR
:::

::: {{custom-style="Portada"}}
Programa de Ingeniería de Sistemas

Ingeniería de Software I
:::

::: {{custom-style="PortadaTitulo"}}
Especifica. Construye. Verifica.
:::

::: {{custom-style="Portada"}}
Examen ISI · Caso ReparaCampus

Desarrollo guiado por especificaciones (SDD) con apoyo de IA

**Equipo:** [COMPLETAR nombre del equipo]
:::

| Integrante | Código |
|:-----------------------|:---------------------|
{filas}

::: {{custom-style="Portada"}}
 

**Grupo:** [COMPLETAR]    **Docente:** [COMPLETAR]    **Fecha:** [COMPLETAR]
:::
"""


TOC = '''
::: {custom-style="TituloIndice"}
Índice
:::

```{=openxml}
<w:p><w:r><w:fldChar w:fldCharType="begin" w:dirty="true"/></w:r><w:r><w:instrText xml:space="preserve">TOC \\o "1-2" \\h \\z \\u</w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>Actualice el índice: clic derecho, Actualizar campo.</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p>
```
'''

partes = [portada(), SALTO, TOC, SALTO,
    "# 3. Problema y alcance\n\n" + (D / "informe/03-intro.md").read_text(encoding="utf-8") + "\n",
    re.sub(r"^# S00 · ([^\n]*)", r"## 3.1 SPEC común S00: \1", leer("specs/S00-comun.md")) + "\n",
    "# 4. Cinco SPECS\n\nCada SPEC incluye historia, alcance, entradas, permisos, reglas, errores, criterios de aceptación Dado / Cuando / Entonces, diseño y tareas vinculadas, pruebas y la decisión de revisión previa. Los campos de autor, revisor, fecha y decisión se completan con la evidencia real de la revisión cruzada, que debe quedar en Git antes del código.\n",
    spec("S01-registrar.md", "4.1"), spec("S02-priorizar-asignar.md", "4.2"), spec("S03-atender.md", "4.3"),
    spec("S04-validar.md", "4.4"), spec("S05-consultar-historial.md", "4.5"),
    "# 5. Diseño\n\n" + leer("docs/informe/05-diseno.md"),
    "# 6. IA e implementación\n\n" + leer("docs/informe/06-ia.md"),
    "# 7. Validación\n\n## 7.1 Matriz de trazabilidad\n\n" + leer("docs/trazabilidad.md"),
    "\n## 7.2 Matriz SPEC / código\n\n" + leer("docs/matriz-spec-codigo.md"),
    "\n## 7.3 Pruebas automatizadas: diez requeridas, tres de integración (T49, T50 y T51)\n\n" + leer("docs/reporte-pruebas.md"),
    "\n" + leer("docs/informe/07-validacion-extra.md"),
    "# 8. Riesgos\n\n" + leer("docs/informe/08-riesgos.md"),
    "# 9. Entrega reproducible\n\n" + leer("docs/informe/09-reproducible.md"),
    "# 10. Contribuciones y cierre\n\n" + leer("docs/informe/10-contribuciones.md"),
    "# 11. Referencias\n\n" + leer("docs/informe/11-referencias.md"),
]
md = "\n\n".join(p if p.endswith("\n") else p + "\n" for p in partes)
# los # de nivel 1 que no son secciones numeradas se evitan: los títulos de SPEC ya son nivel 2
(D / "informe/_informe.md").write_text(md, encoding="utf-8")


def referencia():
    ruta = D / "informe/_ref.docx"
    ruta.write_bytes(subprocess.check_output(["pandoc", "-o", "/dev/stdout", "--print-default-data-file", "reference.docx"]))
    doc = Document(str(ruta))
    s = doc.sections[0]
    s.page_width, s.page_height = Cm(21.0), Cm(29.7)
    s.left_margin = s.right_margin = s.top_margin = s.bottom_margin = Cm(2.5)
    est = doc.styles
    buscar = lambda n: next(x for x in est if x.name == n)
    def fuente(nombre, tam=None, negrita=None, color=None):
        e = buscar(nombre)
        e.font.name = "Arial"
        rf = e.element.rPr.rFonts
        for a in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
            if rf.get(qn(a)) is not None: del rf.attrib[qn(a)]
        for a in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
            rf.set(qn(a), "Arial")
        if tam: e.font.size = Pt(tam)
        if negrita is not None: e.font.bold = negrita
        if color: e.font.color.rgb = RGBColor.from_string(color)
        return e
    for n in ("Normal", "Body Text", "First Paragraph", "Compact"):
        e = fuente(n, 11)
        e.paragraph_format.line_spacing = 1.15
        e.paragraph_format.space_after = Pt(6)
    fuente("Compact", 11).paragraph_format.space_after = Pt(2)
    h1 = fuente("Heading 1", 17, True, "1D2B36"); h1.paragraph_format.page_break_before = True
    h1.paragraph_format.space_after = Pt(10)
    fuente("Heading 2", 13.5, True, "0B5F7A").paragraph_format.space_before = Pt(14)
    fuente("Heading 3", 12, True, "1D2B36")
    for n in ("Image Caption", "Table Caption", "Captioned Figure"):
        if n in [x.name for x in est]: fuente(n, 10)
    from docx.enum.style import WD_STYLE_TYPE
    def nuevo(nombre, tam, negrita=False, antes=0, despues=6):
        e = est.add_style(nombre, WD_STYLE_TYPE.PARAGRAPH)
        e.base_style = buscar("Normal"); e.font.name = "Arial"; e.font.size = Pt(tam); e.font.bold = negrita
        e.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        e.paragraph_format.space_before = Pt(antes); e.paragraph_format.space_after = Pt(despues)
        return e
    nuevo("Portada", 12); nuevo("PortadaGrande", 20, True, 60, 18); nuevo("PortadaTitulo", 26, True, 40, 18)
    nuevo("TituloIndice", 17, True, 0, 12).paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
    # pie de página con número
    p = s.footer.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("ReparaCampus · Examen ISI SDD · Página ")
    r.font.size = Pt(9)
    r2 = p.add_run(); r2.font.size = Pt(9)
    for t, txt in (("begin", None), (None, "PAGE"), ("end", None)):
        if t:
            e = OxmlElement("w:fldChar"); e.set(qn("w:fldCharType"), t)
        else:
            e = OxmlElement("w:instrText"); e.set(qn("xml:space"), "preserve"); e.text = txt
        r2._r.append(e)
    doc.save(str(ruta))
    return ruta


ref = referencia()
salida = D / "informe/Informe_ReparaCampus.docx"
subprocess.check_call(["pandoc", str(D / "informe/_informe.md"), "-f", "markdown+pipe_tables+fenced_divs+raw_attribute",
                       "-o", str(salida), f"--reference-doc={ref}", "--resource-path=" + str(D), "--columns=60"], cwd=str(D))

# ---- ajustes finales: tablas con bordes, resaltado de pendientes ----
doc = Document(str(salida))
ANCHO = 9071  # 16 cm en dxa (A4 con márgenes de 2,5 cm)
def anchos(t):
    n = len(t.columns)
    pesos = []
    for j in range(n):
        m = max((len(f.cells[j].text) for f in t.rows), default=8)
        pesos.append((26 if m <= 12 else min(max(m, 14), 70)) ** 0.85)
    tot = sum(pesos)
    return [int(ANCHO * w / tot) for w in pesos]
for t in doc.tables:
    ws = anchos(t)
    tblPr = t._tbl.tblPr
    for viejo in tblPr.findall(qn("w:tblW")): tblPr.remove(viejo)
    tw = OxmlElement("w:tblW"); tw.set(qn("w:w"), str(ANCHO)); tw.set(qn("w:type"), "dxa"); tblPr.append(tw)
    for viejo in tblPr.findall(qn("w:tblLayout")): tblPr.remove(viejo)
    lay = OxmlElement("w:tblLayout"); lay.set(qn("w:type"), "fixed"); tblPr.append(lay)
    grid = t._tbl.tblGrid
    for gc, w in zip(grid.findall(qn("w:gridCol")), ws): gc.set(qn("w:w"), str(w))
    for fila in t.rows:
        for celda, w in zip(fila.cells, ws):
            tcPr = celda._tc.get_or_add_tcPr()
            for viejo in tcPr.findall(qn("w:tcW")): tcPr.remove(viejo)
            e = OxmlElement("w:tcW"); e.set(qn("w:w"), str(w)); e.set(qn("w:type"), "dxa"); tcPr.insert(0, e)
for t in doc.tables:
    tblPr = t._tbl.tblPr
    for viejo in tblPr.findall(qn("w:tblBorders")): tblPr.remove(viejo)
    b = OxmlElement("w:tblBorders")
    for lado in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement(f"w:{lado}"); e.set(qn("w:val"), "single"); e.set(qn("w:sz"), "4"); e.set(qn("w:color"), "9FB0BA")
        b.append(e)
    tblPr.append(b)
    for i, fila in enumerate(t.rows):
        for celda in fila.cells:
            if i == 0:
                sh = OxmlElement("w:shd"); sh.set(qn("w:val"), "clear"); sh.set(qn("w:fill"), "E3EEF2")
                celda._tc.get_or_add_tcPr().append(sh)
            for par in celda.paragraphs:
                par.paragraph_format.space_after = Pt(1)
                par.paragraph_format.line_spacing = 1.0
                for run in par.runs:
                    run.font.size = Pt(9)
                    if i == 0: run.font.bold = True
def resaltar(parrafos):
    for par in parrafos:
        for run in par.runs:
            if "[COMPLETAR" in run.text:
                run.font.highlight_color = WD_COLOR_INDEX.YELLOW
resaltar(doc.paragraphs)
for t in doc.tables:
    for fila in t.rows:
        for celda in fila.cells:
            resaltar(celda.paragraphs)
doc.save(str(salida))
print("docx listo:", salida)
