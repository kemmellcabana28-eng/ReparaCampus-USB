## 5.1 Componentes y dónde se ejecutan las reglas

El sistema es un monolito modular con tres capas. La interfaz (plantillas Jinja con HTML y CSS) solo presenta formularios y resultados. `routes.py` lee la sesión, verifica el token CSRF y delega. `services.py` contiene todas las reglas, permisos, validaciones y transiciones; ninguna decisión de negocio depende del navegador. `db.py` y SQLite guardan los datos; el estado y el evento se escriben en una sola transacción.

![Figura 1. Componentes de ReparaCampus](diagramas/componentes.png){width=9.5cm}

Cómo se valida una operación: (1) el navegador envía un formulario con la cookie de sesión y el token CSRF; (2) `routes.py` carga el usuario desde la sesión y la base de datos, nunca desde el formulario; (3) `services.py` comprueba el rol, la pertenencia (dueño o técnico asignado), el estado actual y los límites de texto tras el trim; (4) si todo es válido, actualiza el estado con una condición sobre el estado esperado y agrega el evento dentro de `BEGIN IMMEDIATE … COMMIT`; (5) si algo falla, hace `ROLLBACK` y responde con el código HTTP correspondiente (400, 403, 404 o 409) sin cambiar el estado ni el historial.

## 5.2 Modelo de datos

Seis tablas: usuarios, incidencias, asignaciones, soluciones, cierres y eventos. Las soluciones y los cierres se acumulan, nunca se sobrescriben. La tabla eventos es de solo adición: dos triggers (`BEFORE UPDATE` y `BEFORE DELETE`) abortan cualquier modificación, incluso con SQL directo. Las restricciones CHECK de SQLite impiden valores fuera de los permitidos.

![Figura 2. Modelo de datos](diagramas/modelo.png){width=15.5cm}

## 5.3 Diagrama UML de estados

![Figura 3. Estados de una incidencia](diagramas/estados.png){width=14cm}

## 5.4 Secuencia UML del rechazo de una solución

La secuencia incluye los permisos (rol y dueño), los estados incompatibles, la validación del motivo y el evento RECHAZO guardado junto al cambio de estado.

![Figura 4. Secuencia del rechazo de una solución](diagramas/secuencia.png){width=13cm}

## 5.5 Decisión tecnológica justificada

**Decisión.** Monolito modular en Python con Flask y SQLite, interfaz con plantillas Jinja, y pytest para las pruebas.

| Alternativa | Ventaja | Por qué no se eligió |
|:--------------------|:----------------------------|:-------------------------------------|
| Django + SQLite | Autenticación y administración incluidas | Más estructura de la necesaria para cinco funcionalidades; la ruta recomendada del examen es Flask |
| FastAPI + React | Interfaz de una sola página | Duplica la validación en dos capas y añade un frontend que el examen no exige |
| PostgreSQL | Concurrencia y roles de base de datos | Requiere instalar y operar un servidor; innecesario para un prototipo de un solo nodo |

**Consecuencias.** Se gana simplicidad, instalación inmediata, una sola unidad de despliegue y transacciones locales fáciles de probar. Se aceptan límites: SQLite serializa las escrituras (adecuado para este volumen), no hay API separada para otros clientes y las reglas viven en una sola capa (`services.py`), lo que facilita probarlas pero exige disciplina para no duplicarlas en las rutas.
