
::: {custom-style="PortadaGrande"}
UNIVERSIDAD SIMÓN BOLÍVAR
:::

::: {custom-style="Portada"}
Programa de Ingeniería de Sistemas

Ingeniería de Software I
:::

::: {custom-style="PortadaTitulo"}
Especifica. Construye. Verifica.
:::

::: {custom-style="Portada"}
Examen ISI · Caso ReparaCampus

Desarrollo guiado por especificaciones (SDD) con apoyo de IA

**Equipo:** [COMPLETAR nombre del equipo]
:::

| Integrante | Código |
|:-----------------------|:---------------------|
| Kemmell Cabana | [COMPLETAR código] |
| Arnold Cantillo | [COMPLETAR código] |
| Jaider Lozano | [COMPLETAR código] |
| Johan Viviescas | [COMPLETAR código] |
| Sebastian Murcia | [COMPLETAR código] |

::: {custom-style="Portada"}
 

**Grupo:** [COMPLETAR]    **Docente:** [COMPLETAR]    **Fecha:** [COMPLETAR]
:::



```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```




::: {custom-style="TituloIndice"}
Índice
:::

```{=openxml}
<w:p><w:r><w:fldChar w:fldCharType="begin" w:dirty="true"/></w:r><w:r><w:instrText xml:space="preserve">TOC \o "1-2" \h \z \u</w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>Actualice el índice: clic derecho, Actualizar campo.</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p>
```



```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```



# 3. Problema y alcance

La coordinación de mantenimiento de la Universidad Simón Bolívar necesita organizar sus incidencias de infraestructura. Hoy un daño se reporta por un mensaje, se atiende por otro y a veces se da por cerrado sin saber si quedó resuelto. El prototipo ReparaCampus registra los reportes, los prioriza, asigna la atención y comprueba la solución con quien reportó.

| ID | Requisito (resumen) |
|:----|:----------------------------------------------------------------------|
| RF01 | Registrar: el solicitante informa ubicación, categoría, descripción (20 a 500), impacto BAJO o ALTO y riesgo para personas; el sistema genera código, autor, fecha y estado REGISTRADA |
| RF02 | Priorizar y asignar: prioridad CRITICA, ALTA o NORMAL calculada por el sistema; solo el coordinador asigna a un técnico activo |
| RF03 | Atender: solo el técnico asignado inicia la atención y registra una solución (20 a 800) |
| RF04 | Validar: solo el solicitante dueño confirma, rechaza (motivo 10 a 300) o reabre dentro de 48 h del último cierre |
| RF05 | Consultar e historizar: filtros por estado y prioridad según permisos, historial inmutable y tablero del coordinador |

**Límites del prototipo.** Ubicaciones LAB-01, AULA-201 y BIB-01; categorías ELECTRICIDAD, HIDRAULICA, MOBILIARIO y TIC; sin restricción de especialidad del técnico; cinco cuentas ficticias (dos solicitantes, un coordinador y dos técnicos activos); sin adjuntos, notificaciones, hosting ni IA dentro del producto. Todos los datos son ficticios.

Las preguntas al cliente, los supuestos pendientes, los actores, los permisos y las reglas comunes se recogen en la SPEC común S00:



## 3.1 SPEC común S00: Problema, alcance y reglas comunes

**Versión / autor / revisor / fecha:** v1.0 / [COMPLETAR autor] / [COMPLETAR revisor] / [COMPLETAR fecha]

**Necesidad.** La Universidad Simón Bolívar recibe reportes de daños de infraestructura por canales dispersos y a veces los cierra sin saber si quedaron resueltos. Se requiere un prototipo para registrar, priorizar, asignar, atender y validar incidencias.

**Actores y permisos**

| Actor | Puede |
|:----------|:-----------------------------------------------------------|
| SOLICITANTE | Registrar; consultar solo las propias; confirmar, rechazar o reabrir las propias |
| COORDINADOR | Consultar todas; asignar un técnico a incidencias REGISTRADA; ver el tablero. No confirma ni reabre |
| TECNICO | Consultar sus asignadas; iniciar la atención; registrar la solución |

**Estados y transiciones permitidas (únicas)**

- REGISTRADA → ASIGNADA (coordinador)
- ASIGNADA → EN_ATENCION (técnico asignado)
- EN_ATENCION → PENDIENTE_VALIDACION (técnico asignado, con solución)
- PENDIENTE_VALIDACION → CERRADA (solicitante dueño confirma)
- PENDIENTE_VALIDACION → EN_ATENCION (solicitante dueño rechaza con motivo)
- CERRADA → EN_ATENCION (solicitante dueño reabre, ≤ 48 h desde el último cierre)

**Valores permitidos.** Ubicación: LAB-01, AULA-201, BIB-01. Categoría: ELECTRICIDAD, HIDRAULICA, MOBILIARIO, TIC. Impacto: BAJO, ALTO. Riesgo para personas: booleano. Prioridad: CRITICA, ALTA, NORMAL.

**Reglas transversales**

- Identidad y rol se obtienen de la sesión en el servidor; la pertenencia se comprueba en cada operación.
- Los límites de texto se aplican después de retirar espacios externos.
- Las fechas son UTC y las genera el servidor; el cliente no envía la hora efectiva.
- Una operación rechazada no cambia estado ni historial.
- Estado y evento se guardan en una sola transacción (todo o nada).
- El historial es solo de adición: no se edita ni se borra.
- Los textos de usuario se muestran escapados (no se ejecutan como HTML ni scripts).
- No hay cierre automático, edición de reportes ni reasignación.

**Cuentas ficticias (seed).** solicitante1, solicitante2, coordinador1, tecnico1 y tecnico2, con contraseñas ficticias guardadas con hash.

**Preguntas útiles al cliente**

1. ¿Qué debe ver un solicitante cuando abre una incidencia ajena: «no existe» o «sin permiso»?
2. ¿Una incidencia reabierta (EN_ATENCION) cuenta como no cerrada en el porcentaje del tablero?
3. ¿El técnico debe recibir un aviso cuando una incidencia suya se reabre o su solución se rechaza, o basta con que la vea en su lista?

**Supuestos pendientes de confirmar (una respuesta de IA no es una decisión del cliente)**

| ID | Supuesto | Estado |
|:----|:--------------------------------------------------------|:--------------|
| A1 | Leer una incidencia ajena responde 404 para no revelar su existencia | Sin confirmar |
| A2 | El porcentaje usa el estado actual: una incidencia reabierta no cuenta como cerrada | Sin confirmar |
| A3 | El código tiene el formato INC-0001, secuencial | Sin confirmar |
| A4 | El porcentaje se redondea mitad hacia arriba, con un decimal y coma decimal | Sin confirmar |
| A5 | Sin notificaciones: el técnico se entera consultando su lista | Sin confirmar |



# 4. Cinco SPECS

Cada SPEC incluye historia, alcance, entradas, permisos, reglas, errores, criterios de aceptación Dado / Cuando / Entonces, diseño y tareas vinculadas, pruebas y la decisión de revisión previa. Los campos de autor, revisor, fecha y decisión se completan con la evidencia real de la revisión cruzada, que debe quedar en Git antes del código.


## 4.1 SPEC S01 · Registrar incidencia


**Versión / autor / revisor / fecha:** v1.0 / [COMPLETAR autor] / [COMPLETAR revisor] / [COMPLETAR fecha]

**Requisito asociado:** RF01

**Historia.** Como solicitante, quiero registrar una incidencia con ubicación, categoría, descripción, impacto y riesgo, para que mantenimiento pueda priorizarla y atenderla.

**Alcance y exclusiones.** Crear una incidencia. Excluye edición posterior y adjuntos.

**Entradas (todas obligatorias).** ubicación ∈ {LAB-01, AULA-201, BIB-01}; categoría ∈ {ELECTRICIDAD, HIDRAULICA, MOBILIARIO, TIC}; descripción de 20 a 500 caracteres tras retirar espacios externos; impacto ∈ {BAJO, ALTO}; riesgo para personas booleano. El servidor genera código (INC-0001…), autor (sesión), fecha UTC, estado REGISTRADA y prioridad (S02).

**Precondiciones y permisos.** Sesión activa con rol SOLICITANTE.

**Reglas y proceso.** Validar rol → normalizar con trim → validar entradas → calcular prioridad → en una transacción insertar la incidencia y el evento CREACION.

**Salidas y cambios persistidos.** Incidencia REGISTRADA y su evento CREACION; mensaje con el código.

**Errores y efectos que deben evitarse.** Un rol incorrecto o una entrada inválida se rechaza sin crear incidencia ni evento. No se aceptan estado, autor, fecha, código o prioridad enviados por el cliente.

**Criterios de aceptación**

- **AC-S01-01:** Dado un solicitante autenticado, cuando registra datos válidos, entonces se crea con código, autor, fecha UTC y estado REGISTRADA, y existe un evento CREACION.
- **AC-S01-02:** Dado un coordinador o un técnico autenticado, cuando intenta registrar, entonces recibe 403 y no se crea incidencia ni evento.
- **AC-S01-03:** Dado un solicitante, cuando la descripción tiene 19 caracteres tras el trim, entonces se rechaza; con 20 o 500 se acepta; con 501 se rechaza.
- **AC-S01-04:** Dado un solicitante, cuando envía un impacto fuera de {BAJO, ALTO} o un riesgo que no es booleano, entonces se rechaza sin cambios.
- **AC-S01-05:** Dado un solicitante, cuando omite un campo o envía ubicación o categoría fuera de la lista, entonces se rechaza sin cambios.
- **AC-S01-06:** Dado un solicitante, cuando la descripción contiene `<script>alert(1)</script>`, entonces se guarda como texto y se muestra escapada.
- **AC-S01-07:** Dado un fallo al guardar el evento, cuando se registra, entonces no queda una incidencia sin evento.

**Diseño y tareas vinculadas.** Tablas incidencias y eventos; servicio crear_incidencia(); T-S01-1 validación (AC-03/04/05), T-S01-2 servicio transaccional (AC-01/07), T-S01-3 ruta y formulario (AC-01/02/06), T-S01-4 pruebas.

**Pruebas y resultados esperados.** tests/test_s01_registrar.py (t01–t08), con valores límite 19, 20, 500 y 501.

**Decisión de revisión / versión aprobada:** [COMPLETAR: aprobada / ajustar, revisor, fecha]



## 4.2 SPEC S02 · Priorizar y asignar


**Versión / autor / revisor / fecha:** v1.0 / [COMPLETAR autor] / [COMPLETAR revisor] / [COMPLETAR fecha]

**Requisito asociado:** RF02

**Historia.** Como coordinador, quiero que cada incidencia tenga una prioridad calculada y poder asignarla a un técnico activo, para que se atienda según su urgencia.

**Alcance y exclusiones.** Cálculo de prioridad y asignación. Excluye reasignación y restricción por especialidad.

**Entradas.** Código de la incidencia e identificador del técnico.

**Precondiciones y permisos.** Rol COORDINADOR; incidencia REGISTRADA; técnico existente, con rol TECNICO y activo.

**Reglas y proceso.** Prioridad calculada en el servidor: con riesgo, CRITICA; sin riesgo e impacto ALTO, ALTA; sin riesgo e impacto BAJO, NORMAL. Asignar: validar rol → estado REGISTRADA → técnico activo → en una transacción pasar a ASIGNADA, guardar la asignación y el evento ASIGNACION.

**Salidas y cambios persistidos.** Estado ASIGNADA, técnico asignado, fila en asignaciones y evento.

**Errores y efectos que deben evitarse.** No se reasigna una incidencia ya ASIGNADA. Los rechazos no cambian estado ni historial. La prioridad nunca viene del cliente.

**Criterios de aceptación**

- **AC-S02-01:** Dado un coordinador y una incidencia REGISTRADA, cuando la asigna a un técnico activo, entonces pasa a ASIGNADA con ese técnico y se registra el evento.
- **AC-S02-02:** Dado un solicitante o un técnico, cuando intenta asignar, entonces recibe 403 y no hay cambios.
- **AC-S02-03:** Dado una incidencia ya ASIGNADA, cuando el coordinador intenta asignarla de nuevo, entonces se rechaza y se conserva el técnico original.
- **AC-S02-04:** Dado un técnico inexistente, inactivo o que no tiene rol TECNICO, cuando se intenta asignar, entonces se rechaza sin cambios.
- **AC-S02-05:** Dado riesgo=true, o riesgo=false con impacto ALTO, o riesgo=false con impacto BAJO, cuando se registra, entonces la prioridad es CRITICA, ALTA o NORMAL respectivamente.
- **AC-S02-06:** Dado un formulario con un campo «prioridad» manipulado, cuando se registra, entonces el servidor lo ignora y calcula la prioridad.
- **AC-S02-07:** Dado una incidencia que no está REGISTRADA, cuando se intenta asignar, entonces se rechaza.

**Diseño y tareas vinculadas.** Función calcular_prioridad(); servicio asignar(); T-S02-1 prioridad (AC-05/06), T-S02-2 asignación (AC-01/03/04/07), T-S02-3 permisos (AC-02), T-S02-4 pruebas.

**Pruebas y resultados esperados.** tests/test_s02_priorizar_asignar.py (t09–t15). Los esperados se escriben a mano, sin usar la función de producción.

**Decisión de revisión / versión aprobada:** [COMPLETAR: aprobada / ajustar, revisor, fecha]



## 4.3 SPEC S03 · Atender


**Versión / autor / revisor / fecha:** v1.0 / [COMPLETAR autor] / [COMPLETAR revisor] / [COMPLETAR fecha]

**Requisito asociado:** RF03

**Historia.** Como técnico, quiero iniciar la atención de mis incidencias y registrar la solución, para que el solicitante pueda validarla.

**Alcance y exclusiones.** Iniciar atención y registrar solución. Excluye reasignar o editar soluciones.

**Entradas.** Código y texto de la solución (20 a 800 caracteres tras el trim).

**Precondiciones y permisos.** Rol TECNICO y ser el técnico asignado a esa incidencia.

**Reglas y proceso.** Iniciar: ASIGNADA → EN_ATENCION con evento INICIO_ATENCION. Registrar solución: solo desde EN_ATENCION → PENDIENTE_VALIDACION; se guarda una solución nueva sin sobrescribir las anteriores, y el evento SOLUCION.

**Salidas y cambios persistidos.** Nuevo estado, fila en soluciones y evento, todo en una transacción.

**Errores y efectos que deben evitarse.** Un técnico no asignado, otro rol o un estado incorrecto se rechazan sin cambios. No se admite solución antes de iniciar.

**Criterios de aceptación**

- **AC-S03-01:** Dado el técnico asignado y una incidencia ASIGNADA, cuando inicia la atención, entonces pasa a EN_ATENCION y se registra el evento.
- **AC-S03-02:** Dado un técnico que no es el asignado, cuando intenta iniciar o registrar una solución, entonces recibe 403 y no hay cambios.
- **AC-S03-03:** Dado una incidencia ASIGNADA que no se ha iniciado, cuando el técnico registra una solución, entonces se rechaza.
- **AC-S03-04:** Dado una incidencia EN_ATENCION, cuando la solución tiene 19 caracteres se rechaza; con 20 u 800 se acepta; con 801 se rechaza.
- **AC-S03-05:** Dado una incidencia EN_ATENCION y una solución válida, cuando el técnico la registra, entonces pasa a PENDIENTE_VALIDACION, la solución queda guardada y existe el evento SOLUCION.
- **AC-S03-06:** Dado un coordinador o un solicitante, cuando intenta iniciar o registrar una solución, entonces recibe 403 y no hay cambios.
- **AC-S03-07:** Dado una incidencia que no está ASIGNADA, cuando se intenta iniciar la atención, entonces se rechaza.

**Diseño y tareas vinculadas.** Tabla soluciones; servicios iniciar_atencion() y registrar_solucion(); T-S03-1 iniciar (AC-01/02/06/07), T-S03-2 solución (AC-03/04/05), T-S03-3 formularios, T-S03-4 pruebas.

**Pruebas y resultados esperados.** tests/test_s03_atender.py (t16–t22).

**Decisión de revisión / versión aprobada:** [COMPLETAR: aprobada / ajustar, revisor, fecha]



## 4.4 SPEC S04 · Validar


**Versión / autor / revisor / fecha:** v1.0 / [COMPLETAR autor] / [COMPLETAR revisor] / [COMPLETAR fecha]

**Requisito asociado:** RF04

**Historia.** Como solicitante, quiero confirmar, rechazar o reabrir la solución de mi incidencia, para asegurar que el problema quedó resuelto.

**Alcance y exclusiones.** Confirmar, rechazar y reabrir. Excluye cierre automático y acciones del coordinador en nombre del solicitante.

**Entradas.** Código; motivo de 10 a 300 caracteres tras el trim, para rechazar o reabrir.

**Precondiciones y permisos.** Solo el solicitante dueño. El coordinador no confirma ni reabre en su nombre.

**Reglas y proceso.** Confirmar: PENDIENTE_VALIDACION → CERRADA, con un cierre registrado. Rechazar: PENDIENTE_VALIDACION → EN_ATENCION con el mismo técnico, conservando la solución anterior. Reabrir: CERRADA → EN_ATENCION con el mismo técnico, solo si el tiempo desde el último cierre es menor o igual a 48 horas (UTC, calculado por el servidor). Se conservan todos los cierres y soluciones anteriores. El navegador no elige la hora; en pruebas el reloj es inyectable.

**Salidas y cambios persistidos.** Nuevo estado, cierre (si aplica) y evento CIERRE, RECHAZO o REAPERTURA con el motivo.

**Errores y efectos que deben evitarse.** Un usuario que no es el dueño, un estado incorrecto, un motivo inválido o una reapertura fuera de plazo se rechazan sin cambios.

**Criterios de aceptación**

- **AC-S04-01:** Dado el dueño y una incidencia PENDIENTE_VALIDACION, cuando confirma, entonces queda CERRADA con un cierre registrado y su evento.
- **AC-S04-02:** Dado otro solicitante, un coordinador o un técnico, cuando intenta confirmar, rechazar o reabrir, entonces recibe 403 y no hay cambios.
- **AC-S04-03:** Dado el dueño y un reporte PENDIENTE_VALIDACION con técnico T01 y solución registrada, cuando lo rechaza con «El daño sigue presente», entonces queda EN_ATENCION, conserva T01 y la solución anterior, y registra quién rechazó, cuándo y por qué.
- **AC-S04-04:** Dado un motivo de 9 caracteres, cuando rechaza o reabre, entonces se rechaza sin cambios; con 10 o 300 se acepta; con 301 se rechaza.
- **AC-S04-05:** Dado una incidencia CERRADA hace exactamente 48 horas, cuando el dueño la reabre, entonces vuelve a EN_ATENCION con el mismo técnico.
- **AC-S04-06:** Dado una incidencia CERRADA hace 48 horas y 1 segundo, cuando el dueño intenta reabrirla, entonces se rechaza sin cambios.
- **AC-S04-07:** Dado una incidencia reabierta, resuelta y cerrada de nuevo, cuando se reabre otra vez, entonces el plazo se mide desde el último cierre y los cierres y soluciones anteriores siguen en el historial.
- **AC-S04-08:** Dado una incidencia fuera del estado requerido, cuando se intenta confirmar, rechazar o reabrir, entonces se rechaza sin cambios.

**Diseño y tareas vinculadas.** Tabla cierres; reloj inyectable (CLOCK); servicios confirmar(), rechazar() y reabrir(); T-S04-1 confirmar, T-S04-2 rechazar, T-S04-3 reapertura y reloj, T-S04-4 permisos, T-S04-5 pruebas.

**Pruebas y resultados esperados.** tests/test_s04_validar.py (t23–t32), con fechas ficticias fijas y avance controlado del reloj.

**Decisión de revisión / versión aprobada:** [COMPLETAR: aprobada / ajustar, revisor, fecha]



## 4.5 SPEC S05 · Consultar e historizar


**Versión / autor / revisor / fecha:** v1.0 / [COMPLETAR autor] / [COMPLETAR revisor] / [COMPLETAR fecha]

**Requisito asociado:** RF05

**Historia.** Como usuario del sistema, quiero consultar las incidencias que me corresponden y ver su historial, y como coordinador un tablero, para dar seguimiento al trabajo.

**Alcance y exclusiones.** Listado con filtros, detalle con historial y tablero. Excluye edición o borrado de eventos.

**Entradas.** Filtros opcionales de estado y de prioridad (valores permitidos).

**Precondiciones y permisos.** SOLICITANTE: solo las propias. TECNICO: solo las asignadas a él. COORDINADOR: todas, más el tablero.

**Reglas y proceso.** El listado aplica los filtros dentro del alcance del rol. El detalle muestra el historial completo (creación, asignación, inicio, soluciones, motivos, cierres y reaperturas) con autor, fecha, estados y acción. Acceder a una incidencia ajena responde 404 (supuesto A1). El historial es solo de adición, también a nivel de base de datos (triggers). Tablero: cantidades por estado y por prioridad, incidencias CRITICA no cerradas y porcentaje de cierre = CERRADAS / total × 100 con un decimal; con cero registros muestra 0,0 %.

**Salidas y cambios persistidos.** Solo lectura; no modifica datos.

**Errores y efectos que deben evitarse.** Los filtros inválidos se rechazan. Una operación rechazada no agrega eventos.

**Criterios de aceptación**

- **AC-S05-01:** Dado un coordinador, cuando lista, entonces ve todas; con estado=ASIGNADA y prioridad=CRITICA ve solo las que cumplen ambos filtros.
- **AC-S05-02:** Dado un solicitante, cuando lista o abre un detalle, entonces solo accede a las propias; una ajena responde 404.
- **AC-S05-03:** Dado un técnico, cuando lista, entonces solo ve las asignadas a él.
- **AC-S05-04:** Dado una incidencia con un flujo completo, cuando se consulta su historial, entonces muestra todos los eventos en orden con autor, fecha, estados y acción.
- **AC-S05-05:** Dado un evento existente, cuando se intenta actualizar o borrar (desde la aplicación o con SQL directo), entonces la operación falla y el historial no cambia.
- **AC-S05-06:** Dado cero incidencias, cuando el coordinador abre el tablero, entonces el porcentaje de cierre es 0,0 %.
- **AC-S05-07:** Dado cuatro incidencias y una CERRADA, cuando se abre el tablero, entonces muestra 25,0 %; si se reabre, baja a 0,0 % y el cierre anterior sigue en el historial.
- **AC-S05-08:** Dado un solicitante o un técnico, cuando intenta abrir el tablero, entonces recibe 403.
- **AC-S05-09:** Dado un filtro con un valor inválido, cuando se consulta, entonces se rechaza con 400 y no se devuelven resultados engañosos.

**Diseño y tareas vinculadas.** Consultas con alcance por rol; triggers BEFORE UPDATE y BEFORE DELETE sobre eventos; redondeo con Decimal ROUND_HALF_UP; T-S05-1 listado y filtros, T-S05-2 detalle e historial, T-S05-3 triggers, T-S05-4 tablero, T-S05-5 pruebas.

**Pruebas y resultados esperados.** tests/test_s05_consultar_historial.py (t33–t42).

**Decisión de revisión / versión aprobada:** [COMPLETAR: aprobada / ajustar, revisor, fecha]



# 5. Diseño

## 5.1 Componentes y dónde se ejecutan las reglas

El sistema es un monolito modular con tres capas. La interfaz (plantillas Jinja con HTML y CSS) solo presenta formularios y resultados. `routes.py` lee la sesión, verifica el token CSRF y delega. `services.py` contiene todas las reglas, permisos, validaciones y transiciones; ninguna decisión de negocio depende del navegador. `db.py` y SQLite guardan los datos; el estado y el evento se escriben en una sola transacción.

![Figura 1. Componentes de ReparaCampus](diagramas/componentes.png){width=9.5cm}

Cómo se valida una operación: (1) el navegador envía un formulario con la cookie de sesión y el token CSRF; (2) `routes.py` carga el usuario desde la sesión y la base de datos, nunca desde el formulario; (3) `services.py` comprueba el rol, la pertenencia (dueño o técnico asignado), el estado actual y los límites de texto tras el trim; (4) si todo es válido, actualiza el estado con una condición sobre el estado esperado y agrega el evento dentro de `BEGIN IMMEDIATE … COMMIT`; (5) si algo falla, hace `ROLLBACK` y responde con el código HTTP correspondiente (400, 403, 404 o 409) sin cambiar el estado ni el historial.

## 5.2 Modelo de datos

Seis tablas: usuarios, incidencias, asignaciones, soluciones, cierres y eventos. Las soluciones y los cierres se acumulan, nunca se sobrescriben. La tabla eventos es de solo adición: dos triggers (`BEFORE UPDATE` y `BEFORE DELETE`) abortan cualquier modificación, incluso con SQL directo. Las restricciones CHECK de SQLite impiden valores fuera de los permitidos.

![Figura 2. Modelo de datos](diagramas/modelo.png){width=15.5cm}

## 5.3 Diagrama UML de estados

![Figura 3. Estados de una incidencia](diagramas/estados.png){width=14cm}

## 5.4 Secuencia UML del rechazo de una solución

La secuencia incluye los permisos (rol y dueño), los estados incompatibles, la validación del motivo y el evento RECHAZO guardado junto al cambio de estado.

![Figura 4. Secuencia del rechazo de una solución](diagramas/secuencia.png){width=13cm}

## 5.5 Decisión tecnológica justificada

**Decisión.** Monolito modular en Python con Flask y SQLite, interfaz con plantillas Jinja, y pytest para las pruebas.

| Alternativa | Ventaja | Por qué no se eligió |
|:--------------------|:----------------------------|:-------------------------------------|
| Django + SQLite | Autenticación y administración incluidas | Más estructura de la necesaria para cinco funcionalidades; la ruta recomendada del examen es Flask |
| FastAPI + React | Interfaz de una sola página | Duplica la validación en dos capas y añade un frontend que el examen no exige |
| PostgreSQL | Concurrencia y roles de base de datos | Requiere instalar y operar un servidor; innecesario para un prototipo de un solo nodo |

**Consecuencias.** Se gana simplicidad, instalación inmediata, una sola unidad de despliegue y transacciones locales fáciles de probar. Se aceptan límites: SQLite serializa las escrituras (adecuado para este volumen), no hay API separada para otros clientes y las reglas viven en una sola capa (`services.py`), lo que facilita probarlas pero exige disciplina para no duplicarlas en las rutas.


# 6. IA e implementación

## 6.1 Herramientas y versiones

| Uso | Herramienta | Versión |
|:--------------------|:------------------------------|:-------------|
| Asistente de IA | Claude (Anthropic) | Claude Sonnet 5.5 |
| Lenguaje y servidor | Python / Flask / Werkzeug | 3.12.3 / 3.1.3 / 3.1.7 |
| Persistencia | SQLite | 3.45.1 |
| Pruebas | pytest | 9.1.1 |
| Modelado | PlantUML (+ Graphviz) | 1.2024.7 |
| Versionado y tablero | Git + GitHub (issues, Projects, pull requests) | [COMPLETAR] |
| Documento | Word o LibreOffice Writer, exportado a PDF | [COMPLETAR] |

## 6.2 Bitácora de cuatro intervenciones de IA

Las cuatro intervenciones se hicieron con Claude. Las decisiones humanas marcadas como «a confirmar» deben ser ratificadas o corregidas por el equipo según lo que realmente decidió; no se registran como aprobadas sin esa confirmación.

### Intervención 1 · Especificación

**Fecha / autor / herramienta:** 2026-10-11 / [COMPLETAR integrante] / Claude Sonnet 5.5. **Historia y SPEC:** RF01–RF05, S00–S05 v1.0.

**Objetivo y contexto.** Convertir los cinco requisitos del enunciado en una SPEC común y cinco SPECS con criterios Dado / Cuando / Entonces.

**Prompt.** «Transforma estos cinco requisitos en cinco SPECS con historia, alcance, entradas, permisos, reglas, errores y al menos cinco criterios de aceptación que cubran funcionamiento normal, permisos, datos inválidos, límites y estados incompatibles. Incluye tres preguntas al cliente y los supuestos pendientes.» (se adjuntó el enunciado completo).

**Respuesta relevante.** Borradores de S00–S05 con 38 criterios y cinco supuestos (A1–A5), entre ellos que leer una incidencia ajena responde 404.

**Decisión humana y justificación (a confirmar).** Mantener los supuestos A1–A5 como supuestos sin confirmar, porque una respuesta de IA no es una decisión del cliente; revisar los 38 criterios contra el enunciado antes de implementar.

**Error o limitación.** El borrador introdujo decisiones que el enunciado no fija (404 frente a 403, redondeo del porcentaje). Se declaran como supuestos, no como requisitos.

**Corrección y verificación.** Revisión cruzada de cada SPEC por otro integrante. **Archivo:** specs/S00–S05.

### Intervención 2 · Código

**Fecha / autor / herramienta:** 2026-10-11 / [COMPLETAR integrante] / Claude Sonnet 5.5. **Historia y SPEC:** S01–S05 v1.0.

**Objetivo y contexto.** Implementar el servidor Flask con las reglas en la capa de servicios.

**Prompt.** «Implementa S01–S05 en Flask + SQLite. Reglas fijas: identidad y rol salen de la sesión; límites tras el trim; solo las transiciones de S00; estado y evento en una transacción; historial de solo adición; reloj inyectable. No agregues transiciones ni funciones que no estén en la SPEC.»

**Respuesta relevante.** `db/schema.sql`, `app/services.py`, `app/routes.py`, plantillas y `app/seed.py`.

**Decisión humana y justificación (a confirmar).** Aceptar la separación en `services.py` (reglas) y `routes.py` (web), porque permite probar las reglas sin el navegador.

**Error o limitación (real).** En la primera prueba de humo la aplicación falló con `AttributeError: 'function' object has no attribute 'seed'`: en `app/__init__.py` la función importada `seed` tapaba el módulo `app.seed`.

**Corrección y verificación.** Se importó con un alias (`from .seed import seed as cargar_seed`). Se repitió la prueba de humo (login responde 200) y se ejecutó la suite completa. **Archivo:** app/__init__.py.

### Intervención 3 · Pruebas

**Fecha / autor / herramienta:** 2026-10-11 / [COMPLETAR integrante] / Claude Sonnet 5.5. **Historia y SPEC:** S01–S05, AC-S01-01 a AC-S05-09.

**Objetivo y contexto.** Automatizar los criterios con pytest, base SQLite temporal por prueba y reloj controlado.

**Prompt.** «Escribe pruebas pytest para estos criterios usando el cliente de pruebas de Flask y una base SQLite temporal por prueba. Los resultados esperados los escribí yo (tabla adjunta); no los calcules con la función de producción. Reloj controlado, sin esperar 48 horas reales.»

**Respuesta relevante.** 52 escenarios (97 casos), tres de ellos de integración: cierre, rechazo y reapertura.

**Decisión humana y justificación (a confirmar).** Aceptar las pruebas solo después de comprobar que detectan errores (prueba de mutación, sección 7.5).

**Error o limitación (real).** La primera ejecución pasó completa, y eso por sí solo no demuestra que las pruebas detecten errores. Además la suite tarda cerca de 64 s, porque cada base de prueba calcula cinco hashes de contraseña.

**Corrección y verificación.** Seis mutaciones deliberadas del código fueron detectadas por seis pruebas distintas (7.5). **Archivo:** tests/.

### Intervención 4 · Revisión

**Fecha / autor / herramienta:** 2026-10-11 / [COMPLETAR integrante] / Claude Sonnet 5.5. **Historia y SPEC:** S00–S05.

**Objetivo y contexto.** Revisar el código contra las SPECS antes de integrar.

**Prompt.** «Revisa el código contra S00–S05. Busca permisos faltantes en el servidor, transiciones no permitidas, operaciones sin transacción, validaciones sin trim y riesgos de XSS. Lista los hallazgos con archivo y función.»

**Respuesta relevante.** Cuatro hallazgos: (1) no hay límite de intentos de inicio de sesión; (2) `SECRET_KEY` tiene un valor por defecto en el código; (3) leer una incidencia ajena da 404 pero operar sobre ella da 403; (4) `confirmar` repite la comprobación de rol (redundante e inocua).

**Decisión humana y justificación (a confirmar).** Declarar (1), (2) y (3) como limitaciones conocidas en el README y en la sección 9; no cambiar (4) porque no afecta el comportamiento.

**Corrección y verificación.** Limitaciones documentadas en el README; (3) es el supuesto A1 de S00. **Archivo:** README.md, app/services.py.

## 6.3 Evidencia de las cinco funcionalidades

| Funcionalidad | Dónde se usa | Verificación |
|:--------------------|:-------------------------------------------|:-------------------------|
| RF01 Registrar | Menú «Reportar daño» (`/incidencias/nueva`) | T01–T08 |
| RF02 Priorizar y asignar | Detalle de la incidencia, acción «Asignar técnico» | T09–T15 |
| RF03 Atender | Detalle: «Iniciar atención» y «Enviar solución a validación» | T16–T22 |
| RF04 Validar | Detalle: confirmar, rechazar y reabrir | T23–T32, T49–T51 |
| RF05 Consultar e historizar | Listado con filtros, historial en el detalle, `/tablero` | T33–T42 |

Verificación del servidor real (no solo del cliente de pruebas), con `flask --app app run` y curl: GET /login 200, POST /login 302, GET /incidencias 200, GET /incidencias/nueva 200, y GET /tablero como solicitante 403.


# 7. Validación

## 7.1 Matriz de trazabilidad

Cada requisito se conecta con su historia, su SPEC, los criterios de aceptación, el código y las pruebas (Requisito → Historia → SPEC → Código → Prueba).

| RF | Historia | SPEC | Criterios | Código (módulo / función) | Pruebas |
|:---:|:--------------------------|:----:|:--------|:-----------------------------------|:----------------|
| RF01 | Como solicitante, quiero registrar una incidencia | S01 | AC-S01-01 a 07 | services.crear_incidencia; routes.nueva; db/schema.sql | T01–T08 |
| RF02 | Como coordinador, quiero priorizar y asignar | S02 | AC-S02-01 a 07 | services.calcular_prioridad, services.asignar; routes.asignar | T09–T15 |
| RF03 | Como técnico, quiero atender y registrar la solución | S03 | AC-S03-01 a 07 | services.iniciar_atencion, services.registrar_solucion | T16–T22 |
| RF04 | Como solicitante, quiero confirmar, rechazar o reabrir | S04 | AC-S04-01 a 08 | services.confirmar, rechazar, reabrir; reloj CLOCK | T23–T32, T49–T51 |
| RF05 | Como usuario, quiero consultar e historizar; como coordinador, un tablero | S05 | AC-S05-01 a 09 | services.listar, detalle, tablero, formatear_porcentaje; triggers de eventos | T33–T42 |
| Transversal | Acceso, sesión, hash, CSRF, persistencia | S00 | Reglas comunes | routes.login, cargar_usuario, verificar_csrf; seed.py | T43–T48 |



## 7.2 Matriz SPEC / código

Comparación de cada criterio con el código y con la prueba que lo comprueba. El resultado esperado se definió en la SPEC antes de ejecutar; el observado viene del reporte de ejecución (sección 7.3).

| Criterio | Comportamiento esperado | Módulo / función | Prueba | Estado |
|:------|:--------------------------------------|:-------------------|:-----|:------|
| AC-S01-01 | Registro válido: INC-0001, REGISTRADA, autor, fecha UTC, evento CREACION | services.crear_incidencia | T01, T08 | Cumple |
| AC-S01-02 | Coordinador y técnico: 403, sin cambios | services._exigir_rol | T02 | Cumple |
| AC-S01-03 | Descripción 19 y 501 rechazadas; 20 y 500 aceptadas; trim | services._texto | T03 | Cumple |
| AC-S01-04 | Impacto y riesgo inválidos rechazados | services._opcion, _booleano | T04 | Cumple |
| AC-S01-05 | Campos faltantes o fuera de lista rechazados | services._opcion | T05, T05B | Cumple |
| AC-S01-06 | HTML escapado | plantillas Jinja (autoescape) | T06 | Cumple |
| AC-S01-07 | Fallo al guardar el evento: sin incidencia | services.transaccion | T07 | Cumple |
| AC-S02-01 | Asignación válida a ASIGNADA con evento | services.asignar | T11 | Cumple |
| AC-S02-02 | Solo coordinador asigna | services._exigir_rol | T12 | Cumple |
| AC-S02-03 | Asignación repetida rechazada; técnico se conserva | services.asignar | T13 | Cumple |
| AC-S02-04 | Técnico inactivo, de otro rol o inexistente rechazado | services.asignar | T14 | Cumple |
| AC-S02-05 | CRITICA / ALTA / NORMAL según riesgo e impacto | services.calcular_prioridad | T09 | Cumple |
| AC-S02-06 | Prioridad del cliente ignorada | services.crear_incidencia | T10 | Cumple |
| AC-S02-07 | Solo se asigna REGISTRADA | services.asignar | T15 | Cumple |
| AC-S03-01 | Técnico asignado inicia: EN_ATENCION | services.iniciar_atencion | T16 | Cumple |
| AC-S03-02 | Técnico no asignado: 403 | services._cargar_para_tecnico | T17 | Cumple |
| AC-S03-03 | Sin solución antes de iniciar | services.registrar_solucion | T18 | Cumple |
| AC-S03-04 | Solución 19/801 rechazada; 20/800 aceptada | services._texto | T19 | Cumple |
| AC-S03-05 | PENDIENTE_VALIDACION con solución y evento | services.registrar_solucion | T20 | Cumple |
| AC-S03-06 | Coordinador y solicitante: 403 | services._exigir_rol | T21 | Cumple |
| AC-S03-07 | Solo se inicia desde ASIGNADA | services.iniciar_atencion | T22 | Cumple |
| AC-S04-01 | Dueño confirma: CERRADA, cierre y evento | services.confirmar | T23, T49 | Cumple |
| AC-S04-02 | No dueño y otros roles: 403 | services._cargar_para_dueno | T24, T25 | Cumple |
| AC-S04-03 | Rechazo: EN_ATENCION, mismo técnico, solución conservada | services.rechazar | T26, T50 | Cumple |
| AC-S04-04 | Motivo 9/301 rechazado; 10/300 aceptado | services._texto | T27, T28 | Cumple |
| AC-S04-05 | Reapertura a exactamente 48 h aceptada | services.reabrir | T29 | Cumple |
| AC-S04-06 | Reapertura a 48 h y 1 s rechazada sin cambios | services.reabrir | T30 | Cumple |
| AC-S04-07 | Plazo desde el último cierre; todo se conserva | services.reabrir | T31, T51 | Cumple |
| AC-S04-08 | Estados incompatibles rechazados | services.confirmar, rechazar, reabrir | T32 | Cumple |
| AC-S05-01 | Coordinador ve todo; filtros combinados | services.listar | T33 | Cumple |
| AC-S05-02 | Solicitante solo lo propio; ajena 404 | services._alcance, detalle | T34 | Cumple |
| AC-S05-03 | Técnico solo lo asignado | services._alcance | T35 | Cumple |
| AC-S05-04 | Historial completo y ordenado | services.detalle; eventos | T36 | Cumple |
| AC-S05-05 | Eventos inmutables | triggers en db/schema.sql | T37 | Cumple |
| AC-S05-06 | Tablero vacío: 0,0 % | services.tablero, formatear_porcentaje | T38, T42 | Cumple |
| AC-S05-07 | 1 de 4 = 25,0 %; reabrir lo reduce y conserva el cierre | services.tablero | T39, T42 | Cumple |
| AC-S05-08 | Tablero solo para coordinador | services.tablero | T40 | Cumple |
| AC-S05-09 | Filtro inválido: 400 | services.listar | T41 | Cumple |



## 7.3 Pruebas automatizadas: diez requeridas, tres de integración (T49, T50 y T51)

**Comando:** `python -m pytest -v --junitxml=reporte-pytest.xml`  
**Fecha de ejecución:** 2026-10-12 03:38 UTC  
**SHA:** [COMPLETAR: SHA del commit]  
**Resultado:** 97 casos ejecutados en 52 escenarios; 97 casos aprobados.

| ID | SPEC / AC | Escenario y resultado esperado | Casos | Observado |
|:----|:----------|:----------------------------------------------|:---:|:-----------|
| T01 | AC-S01-01 | entrada válida crea INC-0001 REGISTRADA con evento CREACION. | 1 | Cumple |
| T02 | AC-S01-02 | coordinador y técnico reciben 403 y no se crea nada. | 2 | Cumple |
| T03 | AC-S01-03 | 19/20/500/501 caracteres, contando después de retirar espacios externos. | 6 | Cumple |
| T04 | AC-S01-04 | impacto o riesgo fuera de los valores permitidos se rechazan. | 5 | Cumple |
| T05 | AC-S01-05 | ubicación/categoría fuera de lista se rechazan. | 3 | Cumple |
| T05B | AC-S01-05 | un campo omitido se rechaza. | 1 | Cumple |
| T06 | AC-S01-06 | el texto parecido a HTML se muestra escapado. | 1 | Cumple |
| T07 | AC-S01-07 | si falla el evento, no queda incidencia sin evento (rollback). | 1 | Cumple |
| T08 | AC-S01-01 | autor, estado y código enviados por el cliente se ignoran. | 1 | Cumple |
| T09 | AC-S02-05 | prioridad calculada por el servidor según riesgo e impacto. | 4 | Cumple |
| T10 | AC-S02-06 | una prioridad enviada en el formulario no se usa. | 1 | Cumple |
| T11 | AC-S02-01 | coordinador asigna una REGISTRADA a técnico activo. | 1 | Cumple |
| T12 | AC-S02-02 | solicitante o técnico no pueden asignar. | 2 | Cumple |
| T13 | AC-S02-03 | no se reasigna una ASIGNADA; se conserva el técnico original. | 1 | Cumple |
| T14 | AC-S02-04 | técnico inactivo, de otro rol, inexistente o ilegible se rechaza. | 4 | Cumple |
| T15 | AC-S02-07 | no se asigna una incidencia que ya está EN_ATENCION. | 1 | Cumple |
| T16 | AC-S03-01 | el técnico asignado pasa ASIGNADA a EN_ATENCION con evento. | 1 | Cumple |
| T17 | AC-S03-02 | otro técnico no puede iniciar ni registrar solución. | 1 | Cumple |
| T18 | AC-S03-03 | con la incidencia ASIGNADA no se acepta solución. | 1 | Cumple |
| T19 | AC-S03-04 | la solución admite de 20 a 800 caracteres. | 4 | Cumple |
| T20 | AC-S03-05 | solución válida deja PENDIENTE_VALIDACION con solución y evento. | 1 | Cumple |
| T21 | AC-S03-06 | coordinador y solicitante no inician ni dan solución. | 2 | Cumple |
| T22 | AC-S03-07 | no se inicia una incidencia que ya está EN_ATENCION. | 1 | Cumple |
| T23 | AC-S04-01 | el dueño confirma y queda CERRADA con cierre y evento. | 1 | Cumple |
| T24 | AC-S04-02 | otro solicitante, coordinador o técnico no validan. | 6 | Cumple |
| T25 | AC-S04-02 | nadie más puede reabrir una incidencia CERRADA. | 3 | Cumple |
| T26 | AC-S04-03 | rechazo vuelve a EN_ATENCION, conserva técnico y solución, registra motivo. | 1 | Cumple |
| T27 | AC-S04-04 | el motivo del rechazo admite de 10 a 300 caracteres. | 4 | Cumple |
| T28 | AC-S04-04 | el motivo de la reapertura admite de 10 a 300 caracteres. | 4 | Cumple |
| T29 | AC-S04-05 | con exactamente 48 h desde el cierre, la reapertura se acepta. | 1 | Cumple |
| T30 | AC-S04-06 | 48 h y 1 s después del cierre se rechaza sin cambios. | 1 | Cumple |
| T31 | AC-S04-07 | el plazo se mide desde el último cierre y se conserva todo lo anterior. | 1 | Cumple |
| T32 | AC-S04-08 | validar o reabrir fuera del estado permitido se rechaza. | 3 | Cumple |
| T33 | AC-S05-01 | el coordinador ve todo y los filtros se combinan. | 1 | Cumple |
| T34 | AC-S05-02 | el solicitante solo ve las propias; una ajena responde 404. | 1 | Cumple |
| T35 | AC-S05-03 | el técnico solo ve las asignadas a él. | 1 | Cumple |
| T36 | AC-S05-04 | el historial lista cada acción en orden con autor, estados y detalle. | 1 | Cumple |
| T37 | AC-S05-05 | ni UPDATE ni DELETE sobre eventos, ni con SQL directo. | 1 | Cumple |
| T38 | AC-S05-06 | sin incidencias el porcentaje es 0,0 %. | 1 | Cumple |
| T39 | AC-S05-07 | 1 de 4 cerrada = 25,0 %; reabrirla baja a 0,0 % y conserva el cierre. | 1 | Cumple |
| T40 | AC-S05-08 | solicitante y técnico reciben 403 en el tablero. | 2 | Cumple |
| T41 | AC-S05-09 | un filtro con valor inválido se rechaza. | 2 | Cumple |
| T42 | AC-S05-06/07 | formato con coma, un decimal y redondeo half-up. | 6 | Cumple |
| T43 | S00 (transversal) | Acceso con cuentas de prueba: contraseña errónea y usuario falso devuelven 401. | 1 | Cumple |
| T44 | S00 (transversal) | Un campo 'rol' enviado por el cliente no da identidad ni permisos. | 1 | Cumple |
| T45 | S00 (transversal) | Sin sesión no se opera; tras cerrar sesión se pierde el acceso. | 1 | Cumple |
| T46 | S00 (transversal) | Las cinco cuentas existen y la contraseña no se guarda en claro. | 1 | Cumple |
| T47 | S00 (transversal) | Un 'reinicio' (nueva instancia de la app sobre el mismo archivo) conserva todo. | 1 | Cumple |
| T48 | S00 (transversal) | Con CSRF activo, un POST sin token válido se rechaza y no cambia nada. | 1 | Cumple |
| T49 (integración) | S00 (transversal) | Registrar → asignar → iniciar → proponer → confirmar. | 1 | Cumple |
| T50 (integración) | S00 (transversal) | ... proponer → rechazar → nueva solución → confirmar (conserva ambas soluciones). | 1 | Cumple |
| T51 (integración) | S00 (transversal) | Cierre → reapertura → nueva solución → nuevo cierre (todo se conserva). | 1 | Cumple |



## 7.4 Datos, esperados y observados

Cada prueba define su entrada y su resultado esperado en el propio código, escrito a mano antes de ejecutar y sin calcularlo con la función de producción. Ejemplos de datos usados (todos ficticios):

| Escenario | Entrada | Esperado | Observado |
|:----------------------|:------------------------------|:-----------------------|:-----------|
| Descripción límite | 19, 20, 500 y 501 caracteres; 19 y 20 con espacios externos | Rechaza, acepta, acepta, rechaza; rechaza, acepta | Cumple (T03) |
| Prioridad | riesgo sí; sin riesgo con ALTO; sin riesgo con BAJO | CRITICA; ALTA; NORMAL | Cumple (T09) |
| Reapertura a 48 h | Cierre en 2026-03-02 10:00 UTC; reapertura en 2026-03-04 10:00:00 UTC | Acepta, EN_ATENCION, mismo técnico | Cumple (T29) |
| Reapertura pasadas 48 h | Reapertura en 2026-03-04 10:00:01 UTC | Rechaza (409), estado y eventos sin cambios | Cumple (T30) |
| Tablero | 0 incidencias; 1 cerrada de 4; se reabre la cerrada | 0,0 %; 25,0 %; 0,0 % con el cierre conservado | Cumple (T38, T39) |
| Reinicio | Nueva instancia de la app sobre el mismo archivo SQLite | Los datos y eventos siguen ahí | Cumple (T47) |
| Texto parecido a HTML | `<script>alert(1)</script>` en la descripción | Se muestra escapado | Cumple (T06) |

## 7.5 Prueba de mutación y regresión

Para comprobar que las pruebas no aceptan el mismo error del código, se introdujo un defecto a la vez en una copia de `services.py` y se ejecutaron las pruebas relacionadas.

| Mutación | Prueba que debía fallar | Resultado |
|:--------------------------------------------|:-------------|:---------------|
| M1: reabrir acepta también «mayor o igual a 48 h» (cambia `>` por `>=`) | T29 / T30 | Detectada: falló |
| M2: se elimina la comprobación de dueño al validar | T24 / T25 | Detectada: falló |
| M3: se invierten ALTA y NORMAL | T09 | Detectada: falló |
| M4: la descripción mínima pasa de 20 a 19 caracteres | T03 | Detectada: falló |
| M5: el solicitante ve incidencias de otros | T34 | Detectada: falló |
| M6: el rechazo borra el técnico asignado | T26 | Detectada: falló |

Resultado: 6 de 6 mutaciones detectadas. Después de restaurar el código original se ejecutó de nuevo la suite completa (regresión): todos los casos aprobados (sección 7.3).

## 7.6 Hallazgos y regresión

| ID | Hallazgo | Estado | Corrección y verificación |
|:----|:--------------------------------------------------|:---------|:-------------------------------------------|
| D1 | `AttributeError` al iniciar: la función `seed` tapaba el módulo `app.seed` (detectado en la prueba de humo) | Corregido | Importación con alias `cargar_seed`; suite completa aprobada |
| L1 | Sin límite de intentos de inicio de sesión | Limitación declarada | Fuera del alcance del examen |
| L2 | Respuesta 404 al leer y 403 al operar sobre una incidencia ajena | Supuesto A1 sin confirmar | Pendiente de decisión del cliente |
| L3 | No hay pruebas automáticas de navegador | Limitación declarada | Se verificó el servidor real con curl (sección 6.3) |

Los criterios de las matrices figuran como «Cumple» solo porque su prueba se ejecutó y pasó. Ninguno se marca como cumplido sin ejecución.


# 8. Riesgos

Cuatro riesgos: dos relacionados con IA (R1, R2) y dos con el producto o el trabajo del equipo (R3, R4). Una advertencia en el prompt no se considera un control; cada control se vincula a una SPEC o a una prueba.

### 8.1 R1 · La IA inventa que el técnico puede cerrar un reporte (IA)

**Causa.** Un prompt ambiguo o una suposición del modelo agrega una transición que el enunciado no permite (por ejemplo, que el técnico confirme el cierre).

**Impacto.** Una incidencia se cierra sin que el solicitante compruebe la solución: justo el problema que el sistema debe evitar.

**Control.** Las únicas transiciones están en la SPEC común S00 y en `services.py`; cada operación exige el rol y la pertenencia correctos y actualiza el estado solo si el estado actual es el esperado. Los pull requests se revisan contra la tabla de transiciones.

**Responsable.** Revisor del pull request de S04 (propuesto: Jaider Lozano para el código de Johan Viviescas).

**Evidencia de verificación.** T24 (el técnico intenta confirmar: 403, sin cambios), T32 (estados incompatibles) y la mutación M2 (detectada).

### 8.2 R2 · Una prueba acepta el mismo error del código (IA)

**Causa.** La IA genera la prueba y el código a partir de la misma idea, o calcula el esperado con la función de producción, y el error queda «validado» por sí mismo.

**Impacto.** Una suite en verde que da confianza falsa; los defectos llegan a la entrega.

**Control.** Los esperados se escriben a mano antes de ejecutar, con valores de la SPEC; las pruebas de límite usan exactamente 19/20/500/501 y 48 h / 48 h + 1 s; se hace una prueba de mutación y otro integrante revisa las pruebas.

**Responsable.** Autor de las pruebas y su revisor (propuesto: Sebastian Murcia y Johan Viviescas).

**Evidencia de verificación.** Seis mutaciones deliberadas detectadas por seis pruebas (sección 7.5).

### 8.3 R3 · Un solicitante accede a los reportes de otro (producto)

**Causa.** Controles que solo ocultan botones, o consultas sin filtrar por el dueño, o confiar en datos enviados por el cliente.

**Impacto.** Fuga de información y operaciones sobre incidencias ajenas.

**Control.** Identidad y rol salen de la sesión y de la base de datos; cada consulta se filtra por rol (`_alcance`) y cada operación comprueba la pertenencia en el servidor; token CSRF en los formularios; contraseñas con hash.

**Responsable.** Responsable de S05 y de la capa de sesión (propuesto: Sebastian Murcia).

**Evidencia de verificación.** T34 y T35 (alcance por rol y 404), T24 y T25 (otros usuarios: 403), T44 (un campo «rol» no autentica), T48 (CSRF) y la mutación M5 (detectada).

### 8.4 R4 · Un historial engañoso tras una operación fallida (producto)

**Causa.** Un fallo a mitad de una operación deja el estado cambiado sin evento, o un evento sin cambio de estado; o alguien edita el historial.

**Impacto.** No se puede confiar en la trazabilidad de quién hizo qué y cuándo.

**Control.** Estado, solución, cierre y evento se guardan en una transacción (`BEGIN IMMEDIATE … COMMIT`, con `ROLLBACK` ante cualquier error); el `UPDATE` exige el estado esperado; triggers que impiden modificar o borrar eventos; las operaciones rechazadas no escriben nada.

**Responsable.** Responsable del esquema de datos y de las transacciones (propuesto: Arnold Cantillo).

**Evidencia de verificación.** T07 (fallo al guardar el evento: sin incidencia huérfana), T37 (UPDATE y DELETE sobre eventos fallan) y las comprobaciones de «sin eventos nuevos» en T12, T13, T17, T18, T24, T30 y T32.


# 9. Entrega reproducible

**Repositorio:** [COMPLETAR: URL del repositorio en GitHub, con acceso para el docente]

**Tag:** `release-examen`  **SHA exacto:** [COMPLETAR: SHA completo del commit del tag]

**Instalación y arranque (desde una copia limpia).**

```
git clone <URL> && cd reparacampus
git checkout release-examen
python -m venv .venv && source .venv/bin/activate   (Windows: .venv\Scripts\activate)
pip install -r requirements.txt
flask --app app init-db       # esquema + seed con las cinco cuentas ficticias
flask --app app run           # http://127.0.0.1:5000
```

**Cuentas ficticias** (contraseña de todas: `Reparacampus#2026`): solicitante1, solicitante2 (SOLICITANTE); coordinador1 (COORDINADOR); tecnico1, tecnico2 (TECNICO, activos).

**Pruebas.** `python -m pytest -v --junitxml=reporte-pytest.xml` (97 casos en 52 escenarios; tres de integración con SQLite real, también con `python -m pytest -m integracion`). Cada prueba usa una base temporal propia y un reloj controlado.

**Versiones.** Python 3.12.3, Flask 3.1.3, Werkzeug 3.1.7, pytest 9.1.1, SQLite 3.45.1 (detalle en el README y en `requirements.txt`).

**Limitaciones conocidas.** Sin límite de intentos de inicio de sesión; sin notificaciones ni adjuntos; 404 al leer y 403 al operar una incidencia ajena (supuesto A1); no hay pruebas automáticas de navegador; `SECRET_KEY` debe definirse por variable de entorno fuera del entorno de demostración. El README conserva el procedimiento completo.


# 10. Contribuciones y cierre

Reparto propuesto para cinco integrantes. Cada SPEC la redacta un integrante y la revisa otro (revisión circular), y cada integrante revisa al menos un pull request de otra persona. Las columnas de commits, pull requests y fechas deben completarse con la evidencia real del repositorio.

| Integrante | Tareas | Artefactos / commits | Revisión realizada | Resultado |
|:-----------------|:----------------------------------------|:--------------|:------------------------|:----------|
| Kemmell Cabana | S01 Registrar: SPEC, código y pruebas T01–T08; coordinación del PDF | [COMPLETAR commits / PR] | Revisa el PR de S02 (Arnold Cantillo) | [COMPLETAR] |
| Arnold Cantillo | S02 Priorizar y asignar: T09–T15; esquema de datos y transacciones | [COMPLETAR commits / PR] | Revisa el PR de S03 (Jaider Lozano) | [COMPLETAR] |
| Jaider Lozano | S03 Atender: T16–T22; diagramas UML | [COMPLETAR commits / PR] | Revisa el PR de S04 (Johan Viviescas) | [COMPLETAR] |
| Johan Viviescas | S04 Validar: T23–T32 y reloj controlado; pruebas de integración T49–T51 | [COMPLETAR commits / PR] | Revisa el PR de S05 (Sebastian Murcia) | [COMPLETAR] |
| Sebastian Murcia | S05 Consultar e historizar: T33–T42; acceso y sesión T43–T48; matriz de riesgos | [COMPLETAR commits / PR] | Revisa el PR de S01 (Kemmell Cabana) | [COMPLETAR] |

### 10.1 Conclusión sobre el cumplimiento

El prototipo implementa los cinco requisitos con reglas, permisos y validaciones en el servidor, persistencia en SQLite e historial inmutable. Las 97 comprobaciones automatizadas (52 escenarios, tres de integración) se ejecutaron y pasaron, y seis mutaciones deliberadas fueron detectadas por las pruebas. Los 38 criterios de aceptación de S01 a S05 quedan como «Cumple» porque su prueba se ejecutó.

### 10.2 Pendientes declarados

- Evidencia real de Git: repositorio, tablero, issues, commits por integrante, pull requests revisados y SHA del tag `release-examen`.
- Fecha, versión, revisor y decisión de la revisión previa de cada SPEC (S01–S05), registradas antes del código.
- Nombres completos, códigos, grupo, docente y fecha en la portada.
- Confirmación o corrección, por el equipo, de las decisiones humanas de la bitácora de IA.
- Los supuestos A1–A5 siguen sin confirmar con el cliente.

### 10.3 Aceptación del equipo

[COMPLETAR: declaración de aceptación firmada o confirmada por los cinco integrantes, con fecha.]


# 11. Referencias

- Flask: https://flask.palletsprojects.com/
- Werkzeug, utilidades de seguridad (hash de contraseñas): https://werkzeug.palletsprojects.com/
- SQLite: https://www.sqlite.org/docs.html
- pytest: https://docs.pytest.org/
- GitHub Issues y Projects: https://docs.github.com/en/issues
- GitHub Spec Kit: https://github.com/github/spec-kit
- Kiro: https://kiro.dev/docs/
- PlantUML: https://plantuml.com/
- Enunciado del examen: «Especifica. Construye. Verifica.» (ReparaCampus, Universidad Simón Bolívar).

Verifiquen que cada enlace abra antes de exportar el PDF.
