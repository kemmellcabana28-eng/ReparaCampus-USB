Reparto propuesto para cinco integrantes. Cada SPEC la redacta un integrante y la revisa otro (revisión circular), y cada integrante revisa al menos un pull request de otra persona. Las columnas de commits, pull requests y fechas deben completarse con la evidencia real del repositorio.

| Integrante | Tareas | Artefactos / commits | Revisión realizada | Resultado |
|:-----------------|:----------------------------------------|:--------------|:------------------------|:----------|
| Kemmell Cabana | S01 Registrar: SPEC, código y pruebas T01–T08; coordinación del PDF | [COMPLETAR commits / PR] | Revisa el PR de S02 (Arnold Cantillo) | [COMPLETAR] |
| Arnold Cantillo | S02 Priorizar y asignar: T09–T15; esquema de datos y transacciones | [COMPLETAR commits / PR] | Revisa el PR de S03 (Jaider Lozano) | [COMPLETAR] |
| Jaider Lozano | S03 Atender: T16–T22; diagramas UML | [COMPLETAR commits / PR] | Revisa el PR de S04 (Johan Viviescas) | [COMPLETAR] |
| Johan Viviescas | S04 Validar: T23–T32 y reloj controlado; pruebas de integración T49–T51 | [COMPLETAR commits / PR] | Revisa el PR de S05 (Sebastian Murcia) | [COMPLETAR] |
| Sebastian Murcia | S05 Consultar e historizar: T33–T42; acceso y sesión T43–T48; matriz de riesgos | [COMPLETAR commits / PR] | Revisa el PR de S01 (Kemmell Cabana) | [COMPLETAR] |

### 10.1 Conclusión sobre el cumplimiento

El prototipo implementa los cinco requisitos con reglas, permisos y validaciones en el servidor, persistencia en SQLite e historial inmutable. Las 97 comprobaciones automatizadas (52 escenarios, tres de integración) se ejecutaron y pasaron, y seis mutaciones deliberadas fueron detectadas por las pruebas. Los 38 criterios de aceptación de S01 a S05 quedan como «Cumple» porque su prueba se ejecutó.

### 10.2 Pendientes declarados

- Evidencia real de Git: repositorio, tablero, issues, commits por integrante, pull requests revisados y SHA del tag `release-examen`.
- Fecha, versión, revisor y decisión de la revisión previa de cada SPEC (S01–S05), registradas antes del código.
- Nombres completos, códigos, grupo, docente y fecha en la portada.
- Confirmación o corrección, por el equipo, de las decisiones humanas de la bitácora de IA.
- Los supuestos A1–A5 siguen sin confirmar con el cliente.

### 10.3 Aceptación del equipo

[COMPLETAR: declaración de aceptación firmada o confirmada por los cinco integrantes, con fecha.]
