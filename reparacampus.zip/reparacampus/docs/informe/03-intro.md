La coordinación de mantenimiento de la Universidad Simón Bolívar necesita organizar sus incidencias de infraestructura. Hoy un daño se reporta por un mensaje, se atiende por otro y a veces se da por cerrado sin saber si quedó resuelto. El prototipo ReparaCampus registra los reportes, los prioriza, asigna la atención y comprueba la solución con quien reportó.

| ID | Requisito (resumen) |
|:----|:----------------------------------------------------------------------|
| RF01 | Registrar: el solicitante informa ubicación, categoría, descripción (20 a 500), impacto BAJO o ALTO y riesgo para personas; el sistema genera código, autor, fecha y estado REGISTRADA |
| RF02 | Priorizar y asignar: prioridad CRITICA, ALTA o NORMAL calculada por el sistema; solo el coordinador asigna a un técnico activo |
| RF03 | Atender: solo el técnico asignado inicia la atención y registra una solución (20 a 800) |
| RF04 | Validar: solo el solicitante dueño confirma, rechaza (motivo 10 a 300) o reabre dentro de 48 h del último cierre |
| RF05 | Consultar e historizar: filtros por estado y prioridad según permisos, historial inmutable y tablero del coordinador |

**Límites del prototipo.** Ubicaciones LAB-01, AULA-201 y BIB-01; categorías ELECTRICIDAD, HIDRAULICA, MOBILIARIO y TIC; sin restricción de especialidad del técnico; cinco cuentas ficticias (dos solicitantes, un coordinador y dos técnicos activos); sin adjuntos, notificaciones, hosting ni IA dentro del producto. Todos los datos son ficticios.

Las preguntas al cliente, los supuestos pendientes, los actores, los permisos y las reglas comunes se recogen en la SPEC común S00:
