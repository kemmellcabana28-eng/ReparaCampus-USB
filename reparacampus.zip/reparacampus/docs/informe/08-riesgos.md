Cuatro riesgos: dos relacionados con IA (R1, R2) y dos con el producto o el trabajo del equipo (R3, R4). Una advertencia en el prompt no se considera un control; cada control se vincula a una SPEC o a una prueba.

### 8.1 R1 · La IA inventa que el técnico puede cerrar un reporte (IA)

**Causa.** Un prompt ambiguo o una suposición del modelo agrega una transición que el enunciado no permite (por ejemplo, que el técnico confirme el cierre).

**Impacto.** Una incidencia se cierra sin que el solicitante compruebe la solución: justo el problema que el sistema debe evitar.

**Control.** Las únicas transiciones están en la SPEC común S00 y en `services.py`; cada operación exige el rol y la pertenencia correctos y actualiza el estado solo si el estado actual es el esperado. Los pull requests se revisan contra la tabla de transiciones.

**Responsable.** Revisor del pull request de S04 (propuesto: Jaider Lozano para el código de Johan Viviescas).

**Evidencia de verificación.** T24 (el técnico intenta confirmar: 403, sin cambios), T32 (estados incompatibles) y la mutación M2 (detectada).

### 8.2 R2 · Una prueba acepta el mismo error del código (IA)

**Causa.** La IA genera la prueba y el código a partir de la misma idea, o calcula el esperado con la función de producción, y el error queda «validado» por sí mismo.

**Impacto.** Una suite en verde que da confianza falsa; los defectos llegan a la entrega.

**Control.** Los esperados se escriben a mano antes de ejecutar, con valores de la SPEC; las pruebas de límite usan exactamente 19/20/500/501 y 48 h / 48 h + 1 s; se hace una prueba de mutación y otro integrante revisa las pruebas.

**Responsable.** Autor de las pruebas y su revisor (propuesto: Sebastian Murcia y Johan Viviescas).

**Evidencia de verificación.** Seis mutaciones deliberadas detectadas por seis pruebas (sección 7.5).

### 8.3 R3 · Un solicitante accede a los reportes de otro (producto)

**Causa.** Controles que solo ocultan botones, o consultas sin filtrar por el dueño, o confiar en datos enviados por el cliente.

**Impacto.** Fuga de información y operaciones sobre incidencias ajenas.

**Control.** Identidad y rol salen de la sesión y de la base de datos; cada consulta se filtra por rol (`_alcance`) y cada operación comprueba la pertenencia en el servidor; token CSRF en los formularios; contraseñas con hash.

**Responsable.** Responsable de S05 y de la capa de sesión (propuesto: Sebastian Murcia).

**Evidencia de verificación.** T34 y T35 (alcance por rol y 404), T24 y T25 (otros usuarios: 403), T44 (un campo «rol» no autentica), T48 (CSRF) y la mutación M5 (detectada).

### 8.4 R4 · Un historial engañoso tras una operación fallida (producto)

**Causa.** Un fallo a mitad de una operación deja el estado cambiado sin evento, o un evento sin cambio de estado; o alguien edita el historial.

**Impacto.** No se puede confiar en la trazabilidad de quién hizo qué y cuándo.

**Control.** Estado, solución, cierre y evento se guardan en una transacción (`BEGIN IMMEDIATE … COMMIT`, con `ROLLBACK` ante cualquier error); el `UPDATE` exige el estado esperado; triggers que impiden modificar o borrar eventos; las operaciones rechazadas no escriben nada.

**Responsable.** Responsable del esquema de datos y de las transacciones (propuesto: Arnold Cantillo).

**Evidencia de verificación.** T07 (fallo al guardar el evento: sin incidencia huérfana), T37 (UPDATE y DELETE sobre eventos fallan) y las comprobaciones de «sin eventos nuevos» en T12, T13, T17, T18, T24, T30 y T32.
