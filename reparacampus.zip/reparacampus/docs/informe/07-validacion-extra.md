## 7.4 Datos, esperados y observados

Cada prueba define su entrada y su resultado esperado en el propio código, escrito a mano antes de ejecutar y sin calcularlo con la función de producción. Ejemplos de datos usados (todos ficticios):

| Escenario | Entrada | Esperado | Observado |
|:----------------------|:------------------------------|:-----------------------|:-----------|
| Descripción límite | 19, 20, 500 y 501 caracteres; 19 y 20 con espacios externos | Rechaza, acepta, acepta, rechaza; rechaza, acepta | Cumple (T03) |
| Prioridad | riesgo sí; sin riesgo con ALTO; sin riesgo con BAJO | CRITICA; ALTA; NORMAL | Cumple (T09) |
| Reapertura a 48 h | Cierre en 2026-03-02 10:00 UTC; reapertura en 2026-03-04 10:00:00 UTC | Acepta, EN_ATENCION, mismo técnico | Cumple (T29) |
| Reapertura pasadas 48 h | Reapertura en 2026-03-04 10:00:01 UTC | Rechaza (409), estado y eventos sin cambios | Cumple (T30) |
| Tablero | 0 incidencias; 1 cerrada de 4; se reabre la cerrada | 0,0 %; 25,0 %; 0,0 % con el cierre conservado | Cumple (T38, T39) |
| Reinicio | Nueva instancia de la app sobre el mismo archivo SQLite | Los datos y eventos siguen ahí | Cumple (T47) |
| Texto parecido a HTML | `<script>alert(1)</script>` en la descripción | Se muestra escapado | Cumple (T06) |

## 7.5 Prueba de mutación y regresión

Para comprobar que las pruebas no aceptan el mismo error del código, se introdujo un defecto a la vez en una copia de `services.py` y se ejecutaron las pruebas relacionadas.

| Mutación | Prueba que debía fallar | Resultado |
|:--------------------------------------------|:-------------|:---------------|
| M1: reabrir acepta también «mayor o igual a 48 h» (cambia `>` por `>=`) | T29 / T30 | Detectada: falló |
| M2: se elimina la comprobación de dueño al validar | T24 / T25 | Detectada: falló |
| M3: se invierten ALTA y NORMAL | T09 | Detectada: falló |
| M4: la descripción mínima pasa de 20 a 19 caracteres | T03 | Detectada: falló |
| M5: el solicitante ve incidencias de otros | T34 | Detectada: falló |
| M6: el rechazo borra el técnico asignado | T26 | Detectada: falló |

Resultado: 6 de 6 mutaciones detectadas. Después de restaurar el código original se ejecutó de nuevo la suite completa (regresión): todos los casos aprobados (sección 7.3).

## 7.6 Hallazgos y regresión

| ID | Hallazgo | Estado | Corrección y verificación |
|:----|:--------------------------------------------------|:---------|:-------------------------------------------|
| D1 | `AttributeError` al iniciar: la función `seed` tapaba el módulo `app.seed` (detectado en la prueba de humo) | Corregido | Importación con alias `cargar_seed`; suite completa aprobada |
| L1 | Sin límite de intentos de inicio de sesión | Limitación declarada | Fuera del alcance del examen |
| L2 | Respuesta 404 al leer y 403 al operar sobre una incidencia ajena | Supuesto A1 sin confirmar | Pendiente de decisión del cliente |
| L3 | No hay pruebas automáticas de navegador | Limitación declarada | Se verificó el servidor real con curl (sección 6.3) |

Los criterios de las matrices figuran como «Cumple» solo porque su prueba se ejecutó y pasó. Ninguno se marca como cumplido sin ejecución.
