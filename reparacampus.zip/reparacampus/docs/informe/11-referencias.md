- Flask: https://flask.palletsprojects.com/
- Werkzeug, utilidades de seguridad (hash de contraseñas): https://werkzeug.palletsprojects.com/
- SQLite: https://www.sqlite.org/docs.html
- pytest: https://docs.pytest.org/
- GitHub Issues y Projects: https://docs.github.com/en/issues
- GitHub Spec Kit: https://github.com/github/spec-kit
- Kiro: https://kiro.dev/docs/
- PlantUML: https://plantuml.com/
- Enunciado del examen: «Especifica. Construye. Verifica.» (ReparaCampus, Universidad Simón Bolívar).

Verifiquen que cada enlace abra antes de exportar el PDF.
