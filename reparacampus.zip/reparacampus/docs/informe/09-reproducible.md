**Repositorio:** [COMPLETAR: URL del repositorio en GitHub, con acceso para el docente]

**Tag:** `release-examen`  **SHA exacto:** [COMPLETAR: SHA completo del commit del tag]

**Instalación y arranque (desde una copia limpia).**

```
git clone <URL> && cd reparacampus
git checkout release-examen
python -m venv .venv && source .venv/bin/activate   (Windows: .venv\Scripts\activate)
pip install -r requirements.txt
flask --app app init-db       # esquema + seed con las cinco cuentas ficticias
flask --app app run           # http://127.0.0.1:5000
```

**Cuentas ficticias** (contraseña de todas: `Reparacampus#2026`): solicitante1, solicitante2 (SOLICITANTE); coordinador1 (COORDINADOR); tecnico1, tecnico2 (TECNICO, activos).

**Pruebas.** `python -m pytest -v --junitxml=reporte-pytest.xml` (97 casos en 52 escenarios; tres de integración con SQLite real, también con `python -m pytest -m integracion`). Cada prueba usa una base temporal propia y un reloj controlado.

**Versiones.** Python 3.12.3, Flask 3.1.3, Werkzeug 3.1.7, pytest 9.1.1, SQLite 3.45.1 (detalle en el README y en `requirements.txt`).

**Limitaciones conocidas.** Sin límite de intentos de inicio de sesión; sin notificaciones ni adjuntos; 404 al leer y 403 al operar una incidencia ajena (supuesto A1); no hay pruebas automáticas de navegador; `SECRET_KEY` debe definirse por variable de entorno fuera del entorno de demostración. El README conserva el procedimiento completo.
